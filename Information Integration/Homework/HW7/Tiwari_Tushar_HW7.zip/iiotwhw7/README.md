# README

**Make sure you are in root folder**

## For compile and package
```
make
```

## For running the file
```
make run
```

## For deleting output files
```
make clean
```
